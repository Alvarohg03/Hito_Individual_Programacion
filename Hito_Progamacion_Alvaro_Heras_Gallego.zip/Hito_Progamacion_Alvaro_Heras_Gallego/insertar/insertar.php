<?php
$conexion=new PDO('mysql:dbname=test;localhost:3306','root','');
$correo=$_POST['correo'];
$password=$_POST['password'];
$titulo=$_POST['titulo'];
$contenido=$_POST['contenido'];
$foto=$_POST['foto'];
/*Añadir los datos a la base de datos*/
$consultainsertar="INSERT INTO `hitodatos` (`id`, `correo`, `password`, `titulo`, `contenido`, `foto`, `fecha_de_publicacion`) VALUES (NULL, ?, ?, ?, ?, ?, NOW());";
$insertar=$conexion->prepare($consultainsertar);
$resultado=$insertar->execute([$correo,$password,$titulo,$contenido,$foto]);
header('location:../index.html');
