<?php
$id=$_POST['id'];
$conexion=new PDO('mysql:dbname=test;localhost:3306','root','');
$consulta = "DELETE FROM `hitodatos` WHERE id = $id";
$resultado=$conexion->query($consulta); 
header('location:../index.html');

