<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mostrar tabla</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link href="mostrar.css" rel="stylesheet">
  </head>
  <body>
    <ul>
  <li><a href="../cookie/cookiecomprobar.php">Ver Cookie</a></li>
      <li><a href="../insertar/insertar.html">Insertar comentarios</a></li>
      <li><a href="../mostrar/mostrarcomprobar.php">Eliminar/Actualizar entradas</a></li>
      <li><a href="../delete/delete.html">Eliminar usuario</a></li>
      <li><a href="../update/update.html">Actualizar dato del usuario</a></li>
      <li style="float:right"><a class="active" href="../login/login.html">Inicio de sesión</a></li>
    </ul>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <h1>Tabla de usuarios</h1>
    
    <?php
    $conexion=new PDO('mysql:dbname=test;localhost:3306','root','');
    $sql = "SELECT * FROM hitodatos";
    $resultado = $conexion->query($sql);
    echo("<table class='table table-border border-success'>");
    echo("<br>");
  echo("<thead>");
  echo("<tr>");
  echo("<th scope='col'>ID</th>");
  echo("<th scope='col'>Nombre</th>");
  echo("<th scope='col'>Contraseña</th>");
  echo("<th scope='col'>Título</th>");
  echo("<th scope='col'>Contenido</th>");
  echo("<th scope='col'>Imagen</th>");
  echo("<th scope='col'>Fecha de publicación</th>");
    echo("</tr>");
    echo("</thead>");
    echo("<tbody>");
    echo("<tr>");
    while($fila = $resultado->fetch(PDO::FETCH_ASSOC)) {
    echo("<td> ".$fila['id']."</td>");
    echo("<td> ".$fila['correo']." </td>");
    echo("<td> ".$fila['password']." </td>");
    echo("<td> ". $fila['titulo']." </td>");
    echo("<td> ". $fila['contenido']." </td>");
    echo("<td> ". $fila['foto']." </td>");
    echo("<td> ". $fila['fecha_de_publicacion']." </td>");
    echo("</tr>");
    echo("<tr>");
    }
    echo("</tbody>");
    echo("</table>");



?>
  </body>
</html>



