<?php
$id=$_POST['id'];
$contenidonuevo=$_POST['contenidonuevo'];
$titulonuevo=$_POST['titulonuevo'];
$conexion=new PDO('mysql:dbname=test;localhost:3306','root','');
$consulta = "UPDATE `hitodatos` SET titulo='$titulonuevo', contenido='$contenidonuevo' WHERE id=$id";
$resultado=$conexion->query($consulta); 
header('location:../index.html');

